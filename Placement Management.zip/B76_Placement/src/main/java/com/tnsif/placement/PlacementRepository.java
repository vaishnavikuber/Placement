package com.tnsif.placement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlacementRepository extends JpaRepository < Placement ,Integer>
{

}
