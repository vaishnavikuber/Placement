package com.tnsif.placement;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="placement")
public class Placement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String companyName;
	private String jobTitle;
	private LocalDate PlacementDate;
	private Long studentId;
	
	public Placement() {
		super();
	}
	
	public Placement(Long id, String companyName, String jobTitle, LocalDate placementDate, Long studentId) 
	{
		super();
		
		this.companyName = companyName;
		this.jobTitle = jobTitle;
		this.PlacementDate = placementDate;
		this.studentId = studentId;
	}
	
	
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public LocalDate getPlacementDate() {
		return PlacementDate;
	}

	public void setPlacementDate(LocalDate placementDate) {
		PlacementDate = placementDate;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	@Override
	public String toString() {
		return "Placement [id=" + id + ", companyName=" + companyName + ", jobTitle=" + jobTitle + ", PlacementDate="
				+ PlacementDate + ", studentId=" + studentId + ", getId()=" + getId() + ", getCompanyName()="
				+ getCompanyName() + ", getJobTitle()=" + getJobTitle() + ", getPlacementDate()=" + getPlacementDate()
				+ ", getStudentId()=" + getStudentId() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	
}
