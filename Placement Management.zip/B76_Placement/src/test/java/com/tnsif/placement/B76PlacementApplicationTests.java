package com.tnsif.placement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B76PlacementApplicationTests {

	@Test
	void contextLoads() {
	}

}
